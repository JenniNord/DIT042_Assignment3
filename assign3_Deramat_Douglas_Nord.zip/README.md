assign3_Deramat_Douglas_Nord

Author 1: Dominique Deramat
Intern class, 
toString, equals methods (Employee class), 
calculateDegreeLevelBonus switch case rework (Manager),
registerIntern/registerManager/registerDirector,
promotetoIntern/Manager/Employee/Director
Relevant tests

Author 2: Shonaigh Douglas
Manager class, 
Employee class, 
calculateNetSalary overrides (Manager/Director)
calculateTotalGrossSalaries, calculateTotalNetSalaries (ReusaxCorp) 
updateDirectorBenefit link (ReusaxCorp/Director)
promotetoIntern/Manager/Employee/Director
Relevant tests

Author 3: Jennifer Nord
Update of equals method to incorporate null/this/instanceof check
registerEmployee,
retrieveEmployee, 
removeEmployee, 
updateEmployeeName, 
updateEmployeeSalary, 
getTotalNumberOfEmployees,
some bug fixes

Establishment of testing